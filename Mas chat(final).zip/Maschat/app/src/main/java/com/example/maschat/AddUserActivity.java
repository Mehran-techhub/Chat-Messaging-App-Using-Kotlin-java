package com.example.maschat;


import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.maschat.Modelclass.Users;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class AddUserActivity extends AppCompatActivity {

    private AutoCompleteTextView searchInput;
    private Button searchButton;
    private final ArrayList<String> suggestionList = new ArrayList<>();
    private final HashMap<String, Users> usersMap = new HashMap<>(); // to fetch user object on click

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        searchInput = findViewById(R.id.search_input);
        searchButton = findViewById(R.id.search_button);

        loadUsersForSuggestions();

        searchButton.setOnClickListener(v -> {
            String input = searchInput.getText().toString().trim();
            if (input.isEmpty()) {
                Toast.makeText(this, "Please enter username or email", Toast.LENGTH_SHORT).show();
            } else {
                searchUser(input);
            }
        });

        searchInput.setOnItemClickListener((parent, view, position, id) -> {
            String selected = parent.getItemAtPosition(position).toString();
            Users selectedUser = usersMap.get(selected);
            if (selectedUser != null) {
                openChat(selectedUser);
            }
        });
    }

    private void loadUsersForSuggestions() {
        FirebaseDatabase.getInstance().getReference().child("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                            Users user = userSnapshot.getValue(Users.class);
                            if (user != null) {
                                // Add both username and email to suggestion
                                suggestionList.add(user.getUsername());
                                suggestionList.add(user.getMail());
                                usersMap.put(user.getUsername(), user);
                                usersMap.put(user.getMail(), user);
                            }
                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                                AddUserActivity.this,
                                android.R.layout.simple_dropdown_item_1line,
                                suggestionList
                        );
                        searchInput.setAdapter(adapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(AddUserActivity.this, "Failed to load users", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void searchUser(String input) {
        Users user = usersMap.get(input);
        if (user != null) {
            openChat(user);
        } else {
            Toast.makeText(this, "No user found", Toast.LENGTH_SHORT).show();
        }
    }

    private void openChat(Users user) {
        Intent intent = new Intent(AddUserActivity.this, ChatDetailActivity.class);
        intent.putExtra("userid", user.getUserid());
        intent.putExtra("profilePic", user.getProfilepic());
        intent.putExtra("username", user.getUsername());
        startActivity(intent);
        finish();
    }
}
