package com.example.maschat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.maschat.Modelclass.MessageModel;
import com.example.maschat.adapters.ChatAdapter;
import com.example.maschat.databinding.ActivityGroupChatBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;

public class GroupChatActivity extends AppCompatActivity {

    ActivityGroupChatBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGroupChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot()); // ✅

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final ArrayList<MessageModel> messageModels = new ArrayList<>();
        final String senderId = FirebaseAuth.getInstance().getUid();

        binding.username.setText("Group Chat");

        // RecyclerView setup
        final ChatAdapter adapter = new ChatAdapter(messageModels, this);
        binding.ChatRecyclerView.setAdapter(adapter);
        binding.ChatRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Fetch messages
        database.getReference().child("GroupChat")  // ✅ Use consistent naming
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        messageModels.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            MessageModel model = dataSnapshot.getValue(MessageModel.class);
                            messageModels.add(model);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(GroupChatActivity.this, "Failed to load messages", Toast.LENGTH_SHORT).show();
                    }
                });

        // Send message
        binding.send.setOnClickListener(v -> {
            String message = binding.enterMessage.getText().toString().trim();
            if (message.isEmpty()) return;

            MessageModel model = new MessageModel(senderId, message);
            model.setTimestamp(new Date().getTime());

            binding.enterMessage.setText("");

            database.getReference().child("GroupChat") // ✅
                    .push()
                    .setValue(model)
                    .addOnSuccessListener(unused ->
                            Toast.makeText(GroupChatActivity.this, "Message Sent", Toast.LENGTH_SHORT).show());
        });

        // Back arrow
        binding.backArrow.setOnClickListener(v -> {
            Intent intent = new Intent(GroupChatActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        // Optional buttons (can add actual logic here)
        binding.imageView4.setOnClickListener(v ->
                Toast.makeText(this, "Call feature coming soon", Toast.LENGTH_SHORT).show());

        binding.imageView5.setOnClickListener(v ->
                Toast.makeText(this, "Video call feature coming soon", Toast.LENGTH_SHORT).show());

        binding.imageView6.setOnClickListener(v ->
                Toast.makeText(this, "Menu options coming soon", Toast.LENGTH_SHORT).show());
    }
}
