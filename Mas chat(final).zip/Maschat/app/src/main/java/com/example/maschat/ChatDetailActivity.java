package com.example.maschat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.maschat.Modelclass.MessageModel;
import com.example.maschat.adapters.ChatAdapter;
import com.example.maschat.databinding.ActivityChatDetailBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Date;

public class ChatDetailActivity extends AppCompatActivity {

    ActivityChatDetailBinding binding;
    FirebaseDatabase database;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ Use ViewBinding ONLY
        binding = ActivityChatDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportActionBar().hide();

        // ✅ Init Firebase
        database = FirebaseDatabase.getInstance();
        auth = FirebaseAuth.getInstance();

        // ✅ Get intent data
        final String senderId = auth.getUid();
        final String receiverId = getIntent().getStringExtra("userid");
        String username = getIntent().getStringExtra("username");
        String profilePic = getIntent().getStringExtra("profilePic");

        // ✅ Set user data in UI
        binding.username.setText(username);
        Picasso.get().load(profilePic).placeholder(R.drawable.avatar).into(binding.profileImage);

        Log.d("ChatDetail", "Username: " + username + ", Receiver ID: " + receiverId);

        // ✅ Back button
        binding.backArrow.setOnClickListener(v -> {
            startActivity(new Intent(ChatDetailActivity.this, MainActivity.class));
            finish(); // optional
        });

        // ✅ Set up RecyclerView
        final ArrayList<MessageModel> messageModels = new ArrayList<>();
        final ChatAdapter chatAdapter = new ChatAdapter(messageModels, this, receiverId);
        binding.ChatRecyclerView.setAdapter(chatAdapter);
        binding.ChatRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        final String senderRoom = senderId + receiverId;
        final String receiverRoom = receiverId + senderId;

        // ✅ Load previous messages
        database.getReference().child("chats").child(senderRoom)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        messageModels.clear();
                        for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                            MessageModel model = snapshot1.getValue(MessageModel.class);
                            if (model != null) {
                                model.setMessageid(snapshot1.getKey());
                                messageModels.add(model);
                            }
                        }
                        chatAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("ChatDetail", "Failed to read messages", error.toException());
                    }
                });

        // ✅ Sending messages
        binding.send.setOnClickListener(v -> {
            String message = binding.enterMessage.getText().toString().trim();
            if (message.isEmpty()) return;

            final MessageModel model = new MessageModel(senderId, message);
            model.setTimestamp(new Date().getTime());
            binding.enterMessage.setText("");

            database.getReference().child("chats").child(senderRoom)
                    .push().setValue(model)
                    .addOnSuccessListener(unused -> database.getReference().child("chats")
                            .child(receiverRoom).push().setValue(model));
        });
    }
}
