package com.example.maschat.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.maschat.Modelclass.MessageModel;
import com.example.maschat.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final ArrayList<MessageModel> messageModels;
    private final Context context;
    private final String recId;          // null for group chat

    private static final int SENDER_VIEW_TYPE   = 1;
    private static final int RECEIVER_VIEW_TYPE = 2;

    // 3-arg constructor for 1:1 chat
    public ChatAdapter(ArrayList<MessageModel> messageModels, Context context, String recId) {
        this.messageModels = messageModels;
        this.context       = context;
        this.recId         = recId;
    }

    // 2-arg constructor for group chat
    public ChatAdapter(ArrayList<MessageModel> messageModels, Context context) {
        this.messageModels = messageModels;
        this.context       = context;
        this.recId         = null;
    }

    @Override
    public int getItemViewType(int position) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (messageModels.get(position).getUid().equals(uid)) {
            return SENDER_VIEW_TYPE;
        } else {
            return RECEIVER_VIEW_TYPE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType
    ) {
        LayoutInflater inflater = LayoutInflater.from(context);
        if (viewType == SENDER_VIEW_TYPE) {
            View view = inflater.inflate(R.layout.sample_sender, parent, false);
            return new SenderViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.sample_reciver, parent, false);
            return new ReceiverViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(
            @NonNull RecyclerView.ViewHolder holder, int position
    ) {
        MessageModel model = messageModels.get(position);
        String timeString  = new SimpleDateFormat("h:mm a")
                .format(new Date(model.getTimestamp()));

        // Bind UI & Time
        if (holder instanceof SenderViewHolder) {
            ((SenderViewHolder) holder).senderMsg.setText(model.getMessage());
            ((SenderViewHolder) holder).senderTime.setText(timeString);
        } else {
            ((ReceiverViewHolder) holder).receiverMsg.setText(model.getMessage());
            ((ReceiverViewHolder) holder).receiverTime.setText(timeString);
        }

        // Long-press delete
        holder.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete")
                    .setMessage("Are you sure you want to delete this message?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        FirebaseDatabase db = FirebaseDatabase.getInstance();
                        if (recId != null) {
                            // 1:1 chat deletion
                            String senderRoom = FirebaseAuth.getInstance().getUid() + recId;
                            db.getReference()
                                    .child("chats")
                                    .child(senderRoom)
                                    .child(model.getMessageid())
                                    .removeValue();
                        } else {
                            // Group chat deletion
                            db.getReference()
                                    .child("GroupChat")
                                    .child(model.getMessageid())
                                    .removeValue();
                        }
                    })
                    .setNegativeButton("No", (d, w) -> d.dismiss())
                    .show();
            return true;  // consume the event
        });
    }

    @Override
    public int getItemCount() {
        return messageModels.size();
    }

    // ViewHolder for sent messages
    static class SenderViewHolder extends RecyclerView.ViewHolder {
        TextView senderMsg, senderTime;
        SenderViewHolder(@NonNull View itemView) {
            super(itemView);
            senderMsg  = itemView.findViewById(R.id.sender_Text);
            senderTime = itemView.findViewById(R.id.sendertime);
        }
    }

    // ViewHolder for received messages
    static class ReceiverViewHolder extends RecyclerView.ViewHolder {
        TextView receiverMsg, receiverTime;
        ReceiverViewHolder(@NonNull View itemView) {
            super(itemView);
            receiverMsg  = itemView.findViewById(R.id.receiverText);
            receiverTime = itemView.findViewById(R.id.receiverTime);
        }
    }
}
