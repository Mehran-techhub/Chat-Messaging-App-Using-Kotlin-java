package com.example.maschat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.maschat.databinding.ActivitySettingsBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Settings extends AppCompatActivity {

    ActivitySettingsBinding binding;
    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        // Hide Action Bar
//        getSupportActionBar().hide();

        // Firebase instances
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        // Load existing user data
        String uid = auth.getCurrentUser().getUid();
        DatabaseReference reference = database.getReference("Users").child(uid);

        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String username = snapshot.child("username").getValue(String.class);
                    String about = snapshot.child("about").getValue(String.class);

                    binding.txtUsername.setText(username);
                    binding.etStatus.setText(about);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(Settings.this, "Failed to load user data", Toast.LENGTH_SHORT).show();
            }
        });

        // Back button
        binding.backArrow.setOnClickListener(v -> {
            startActivity(new Intent(Settings.this, MainActivity.class));
            finish();
        });

        // Save button logic
        binding.savebutton.setOnClickListener(v -> {
            String username = binding.txtUsername.getText().toString().trim();
            String about = binding.etStatus.getText().toString().trim();

            if (username.isEmpty() || about.isEmpty()) {
                Toast.makeText(Settings.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            } else {
                HashMap<String, Object> updates = new HashMap<>();
                updates.put("username", username);
                updates.put("about", about);

                reference.updateChildren(updates)
                        .addOnSuccessListener(unused ->
                                Toast.makeText(Settings.this, "Updated successfully!", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e ->
                                Toast.makeText(Settings.this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });

        // (Optional) Bottom options click listeners if you want to handle those too
    }
}
